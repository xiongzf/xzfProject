//
//  TouchView.h
//  MacOsLikeMenuAnnimation
//
//  Created by Слава on 18.11.09.
//  Copyright 2009 Slava Bushtruk. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TouchView : UIView 
{
}

@end
