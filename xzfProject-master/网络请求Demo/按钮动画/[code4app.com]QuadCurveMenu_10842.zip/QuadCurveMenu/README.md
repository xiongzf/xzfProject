QuadCurveMenu is a menu looks like [Path](https://path.com/)'s story menu.

Enjoy to use it:)

![screenshots](http://lunaapp.com/images/external/qcmenu2.gif)