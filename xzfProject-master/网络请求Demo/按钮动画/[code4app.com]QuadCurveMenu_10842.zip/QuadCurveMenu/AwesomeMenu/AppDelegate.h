//
//  AppDelegate.h
//  AwesomeMenu
//
//  Created by Levey on 11/30/11.
//  Copyright (c) 2011 lunaapp.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QuadCurveMenu.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate, QuadCurveMenuDelegate>

@property (retain, nonatomic) UIWindow *window;

@end
