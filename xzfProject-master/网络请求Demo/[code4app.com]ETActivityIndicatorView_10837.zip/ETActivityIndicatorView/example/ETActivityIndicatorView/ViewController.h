//
//  ViewController.h
//  ETActivityIndicatorView
//
//  Created by Eugene Trapeznikov on 5/23/13.
//  Copyright (c) 2013 Eugene Trapeznikov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
