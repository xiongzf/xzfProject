//
//  Circle.h
//  ETActivityIndicatorView
//
//  Created by Eugene Trapeznikov on 5/26/13.
//  Copyright (c) 2013 Eugene Trapeznikov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Circle : UIView

@property (nonatomic,retain) UIColor *color;

@end
