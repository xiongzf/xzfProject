//
//  main.m
//  WifiFtpServer
//
//  Created by 吴晓明 on 13-11-7.
//  Copyright (c) 2013年 吴晓明. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
