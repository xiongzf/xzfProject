//
//  WTURLSessionManager.h
//  WTRequestCenter
//
//  Created by song on 14-8-1.
//  Copyright (c) 2014年 song. All rights reserved.
//

#import <Foundation/Foundation.h>
#if (defined(__IPHONE_OS_VERSION_MAX_ALLOWED) && __IPHONE_OS_VERSION_MAX_ALLOWED >= 70000) || (defined(__MAC_OS_X_VERSION_MAX_ALLOWED) && __MAC_OS_X_VERSION_MAX_ALLOWED >= 1090)
@interface WTURLSessionManager : NSObject

@end
#endif