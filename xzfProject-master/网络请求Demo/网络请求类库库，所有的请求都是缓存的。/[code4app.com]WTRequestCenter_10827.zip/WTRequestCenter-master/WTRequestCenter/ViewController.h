//
//  ViewController.h
//  WTRequestCenter
//
//  Created by song on 14-7-19.
//  Copyright (c) 2014年 song. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIImageView+WTImageCache.h"
@interface ViewController : UIViewController

@end
