//
//  MyBookShellCell.h
//  BookShelf
//
//  Created by mac on 12-9-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyBookShellCell : UITableViewCell

@property (nonatomic,retain)UILabel * label;

@property (nonatomic,retain)UIImageView * imageView;

@end
