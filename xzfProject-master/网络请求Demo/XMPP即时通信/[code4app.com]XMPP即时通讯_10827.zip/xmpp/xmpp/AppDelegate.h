//
//  AppDelegate.h
//  xmpp
//
//  Created by In8 on 14-4-21.
//  Copyright (c) 2014年 zjj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
