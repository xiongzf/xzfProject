//
//  Constant.h
//  xmpp
//
//  Created by In8 on 14-4-23.
//  Copyright (c) 2014年 zjj. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kUserName    @"userName"
#define kPassword    @"password"
#define kServerHost  @"serverHost"
#define kDomain      @"in"