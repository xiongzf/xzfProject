//
//  ChatViewController.h
//  xmpp
//
//  Created by In8 on 14-4-23.
//  Copyright (c) 2014年 zjj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatViewController : UIViewController <MyXMPPDelegate>
@property (nonatomic , copy) NSString *toUserid;

@end
